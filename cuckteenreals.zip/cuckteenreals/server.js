const express = require('express');
const path = require('path');
const session = require('express-session');

const app = express();
const port = process.env.PORT || 3000;
const orders = [];
const completedOrders = [];
const rejectedOrders = [];
const inProgressOrders = [];
const readyOrders = [];
const onDeliveryOrders = [];
const paymentPendingOrders = [];
const refundedOrders = [];
const cancelledOrders = [];
const deliveredOrders = [];

// Middleware setup
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// CORS middleware
app.use((req, res, next) => {
    console.log(`Incoming request: ${req.method} ${req.url}`); // Log incoming requests
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET, POST, DELETE, OPTIONS');
    res.header('Access-Control-Allow-Headers', 'Content-Type');
    
    if (req.method === 'OPTIONS') {
        res.sendStatus(200);
    } else {
        next();
    }
});

// Session middleware
app.use(session({
    secret: process.env.SESSION_SECRET || 'default-secret',
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false } // Set to true if using HTTPS
}));

// Admin login routes - MUST come before static file serving
app.get('/admin/login', (req, res) => {
    console.log('Admin login route accessed');
    res.sendFile(path.join(__dirname, 'public/admin-login.html'));
});

// Admin login endpoint
app.post('/admin/login', (req, res) => {
    const { key } = req.body;
    const ADMIN_KEY = '123'; // Set admin key to '123'

    if (key === ADMIN_KEY) {
        req.session.isAdmin = true; // Set admin session
        console.log('Admin session set:', req.session); // Log session state
        return res.json({ success: true, redirect: '/orders.html' });
    } else {
        return res.status(401).json({ success: false, message: 'Invalid admin key' });
    }
});

// Endpoint to check admin status
app.get('/auth/status', (req, res) => {
    res.json({ isAdmin: req.session.isAdmin || false });
});

// Route for completed orders page
app.get('/completed-orders.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'public/completed-orders.html'));
});

// Serve static files - MUST come after routes
app.use(express.static(path.join(__dirname, 'public')));

// Route for homepage
app.get('/', (req, res) => {
  console.log('Homepage route accessed');
  res.sendFile(path.join(__dirname, 'index.html'));
});

// Route for orders page
app.get('/orders', (req, res) => {
  console.log('Orders route accessed. Session:', req.session); // Log session state
  res.sendFile(path.join(__dirname, 'public/orders.html'));
});

// DELETE route to complete an order (legacy - kept for backward compatibility)
app.delete('/orders/:id', (req, res) => {
    const orderId = req.params.id;
    const orderIndex = orders.findIndex(order => order.id === orderId);

    if (orderIndex !== -1) {
        const completedOrder = orders.splice(orderIndex, 1)[0]; // Remove the order
        completedOrders.push(completedOrder); // Move to completed orders
        return res.json({ success: true, message: 'Order completed and moved!' });
    } else {
        return res.status(404).json({ success: false, message: 'Order not found' });
    }
});

// PUT route to update order status
app.put('/orders/:id/status', (req, res) => {
    const orderId = req.params.id;
    const { status } = req.body;
    
// Valid statuses
    const validStatuses = ['pending', 'in-progress', 'ready', 'completed', 'rejected', 'on-delivery', 'payment-pending', 'refunded', 'cancelled', 'delivered'];
    
    if (!validStatuses.includes(status)) {
        return res.status(400).json({ success: false, message: 'Invalid status' });
    }
    
    let order = null;
    let sourceArray = null;
    
    // Find the order in any array
    const allOrders = [
        { array: orders, name: 'pending' },
        { array: inProgressOrders, name: 'in-progress' },
        { array: readyOrders, name: 'ready' },
        { array: completedOrders, name: 'completed' },
        { array: rejectedOrders, name: 'rejected' },
        { array: onDeliveryOrders, name: 'on-delivery' },
        { array: paymentPendingOrders, name: 'payment-pending' },
        { array: refundedOrders, name: 'refunded' },
        { array: cancelledOrders, name: 'cancelled' },
        { array: deliveredOrders, name: 'delivered' }
    ];
    
    for (const { array } of allOrders) {
        const orderIndex = array.findIndex(o => o.id === orderId);
        if (orderIndex !== -1) {
            order = array.splice(orderIndex, 1)[0];
            sourceArray = array;
            break;
        }
    }
    
    if (!order) {
        return res.status(404).json({ success: false, message: 'Order not found' });
    }
    
    // Add to appropriate array based on new status
    switch (status) {
        case 'pending':
            orders.push(order);
            break;
        case 'in-progress':
            inProgressOrders.push(order);
            break;
        case 'ready':
            readyOrders.push(order);
            break;
        case 'completed':
            completedOrders.push(order);
            break;
        case 'rejected':
            rejectedOrders.push(order);
            break;
        case 'on-delivery':
            onDeliveryOrders.push(order);
            break;
        case 'payment-pending':
            paymentPendingOrders.push(order);
            break;
        case 'refunded':
            refundedOrders.push(order);
            break;
        case 'cancelled':
            cancelledOrders.push(order);
            break;
        case 'delivered':
            deliveredOrders.push(order);
            break;
    }
    
    res.json({ success: true, message: `Order status updated to ${status}` });
});

// Endpoint to get completed orders
app.get('/api/completed-orders', (req, res) => {
    res.json(completedOrders);
});

// Endpoint to get rejected orders
app.get('/api/rejected-orders', (req, res) => {
    res.json(rejectedOrders);
});

// Endpoint to get in-progress orders
app.get('/api/in-progress-orders', (req, res) => {
    res.json(inProgressOrders);
});

// Endpoint to get ready orders
app.get('/api/ready-orders', (req, res) => {
    res.json(readyOrders);
});

// Endpoint to get all orders by status
app.get('/api/orders-by-status', (req, res) => {
    const allOrders = {
        pending: orders,
        'in-progress': inProgressOrders,
        ready: readyOrders,
        completed: completedOrders,
        rejected: rejectedOrders
    };
    res.json(allOrders);
});

// Other routes and server setup...
app.post('/order', (req, res) => {
  const order = req.body; // Now includes name and phone
  order.id = Date.now().toString(); // Add unique ID
  
  // Generate order number (sequential counter)
  const allOrders = [
    ...orders,
    ...inProgressOrders,
    ...readyOrders,
    ...completedOrders,
    ...rejectedOrders
  ];
  const orderNumber = allOrders.length + 1;
  order.orderNumber = orderNumber;
  
  orders.push(order);
  console.log('Received order:', order);
  res.json({ success: true, message: 'Order received!', orderNumber });
});

// Temporary endpoint to view current orders
app.get('/api/orders', (req, res) => {
    res.json(orders);
});

// Endpoint to get orders by phone number
app.get('/api/my-orders/:phone', (req, res) => {
    const phone = req.params.phone;
    const myOrders = [
        ...orders.map(o => ({...o, status: 'pending'})),
        ...inProgressOrders.map(o => ({...o, status: 'in-progress'})),
        ...readyOrders.map(o => ({...o, status: 'ready'})),
        ...completedOrders.map(o => ({...o, status: 'completed'})),
        ...rejectedOrders.map(o => ({...o, status: 'rejected'}))
    ].filter(order => order.phone === phone);
    
    res.json(myOrders);
});

// Start the server
app.listen(port, '0.0.0.0', () => {
  console.log(`Canteen website running at http://localhost:${port}`);
  console.log(`Accessible on LAN at http://10.0.0.203:${port}`);
});
