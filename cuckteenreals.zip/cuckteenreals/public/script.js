let order = [];
let totalPrice = 0;

// Function to update the order summary
function updateOrderSummary() {
    const orderList = document.getElementById('order-list');
    const totalPriceElement = document.getElementById('total-price');
    
    // Clear the order list
    orderList.innerHTML = '';

    // Add each item in the order to the list
    order.forEach(item => {
        const li = document.createElement('li');
        li.textContent = `${item.name} - $${item.price.toFixed(2)} (x${item.quantity})`;
        orderList.appendChild(li);
    });

    // Update the total price
    totalPriceElement.textContent = totalPrice.toFixed(2);
}

// Function to display customer's orders
function displayMyOrders(orders) {
    const myOrdersDiv = document.getElementById('my-orders');
    const myOrdersList = document.getElementById('my-orders-list');
    
    if (orders.length === 0) {
        myOrdersList.innerHTML = '<p>No orders found for this phone number.</p>';
        myOrdersDiv.style.display = 'block';
        return;
    }

    myOrdersList.innerHTML = '';
    orders.forEach(order => {
        const orderCard = document.createElement('div');
        orderCard.className = 'my-order-card';
        
        const statusClass = `status-${order.status.toLowerCase()}`;
        const statusText = order.status.charAt(0).toUpperCase() + order.status.slice(1);
        
        orderCard.innerHTML = `
            <h4>Order #${order.orderNumber || order.id.slice(-4)}</h4>
            <p><strong>Name:</strong> ${order.firstName} ${order.lastName}</p>
            <p><strong>Phone:</strong> ${order.phone}</p>
            <p><strong>Total:</strong> $${order.total.toFixed(2)}</p>
            <p><strong>Status:</strong> <span class="order-status ${statusClass}">${statusText}</span></p>
            <p><strong>Items:</strong></p>
            <ul>
                ${order.items.map(item => `<li>${item.name} - $${item.price.toFixed(2)} (x${item.quantity})</li>`).join('')}
            </ul>
            <p><strong>Ordered:</strong> ${new Date(parseInt(order.id)).toLocaleString()}</p>
        `;
        
        myOrdersList.appendChild(orderCard);
    });
    
    myOrdersDiv.style.display = 'block';
}

// Function to check for status changes and show notifications
function checkForStatusChanges(phone, previousOrders = []) {
    const viewPhoneInput = document.getElementById('view-phone');
    const currentPhone = viewPhoneInput ? viewPhoneInput.value.trim() : phone;

    fetch(`/api/my-orders/${currentPhone}`)
        .then(response => response.json())
        .then(currentOrders => {
            if (previousOrders.length > 0) {
                currentOrders.forEach(currentOrder => {
                    const previousOrder = previousOrders.find(o => o.id === currentOrder.id);
                    if (previousOrder && previousOrder.status !== currentOrder.status) {
                        showNotification(`Order #${currentOrder.orderNumber || currentOrder.id.slice(-4)} status changed to ${currentOrder.status}`);
                    }
                });
            }
            // Store current orders for next comparison
            window.previousOrders = currentOrders;
        })
        .catch(error => console.error('Error checking status:', error));
}

// Function to show notification
function showNotification(message) {
    // Check if browser supports notifications
    if ('serviceWorker' in navigator && navigator.serviceWorker.controller) {
        navigator.serviceWorker.controller.postMessage({
            type: 'showNotification',
            title: 'Order Status Update',
            message: message,
            icon: '/favicon.ico'
        });
    } else {
        // Fallback to alert if service worker is not available
        alert('📱 ' + message);
    }
}

// Enhanced order tracking with notifications
let orderTrackingInterval;
let previousOrders = [];

function startOrderTracking(phone) {
    // Initial check
    checkForStatusChanges(phone);

    // Check every 5 seconds
    orderTrackingInterval = setInterval(() => {
        checkForStatusChanges(phone, window.previousOrders);
    }, 5000);
}

function stopOrderTracking() {
    if (orderTrackingInterval) {
        clearInterval(orderTrackingInterval);
    }
}

document.addEventListener('DOMContentLoaded', () => {
    if ('serviceWorker' in navigator) {
        navigator.serviceWorker.register('/service-worker.js')
            .then(registration => {
                console.log('Service worker registered:', registration);
            })
            .catch(error => {
                console.error('Service worker registration failed:', error);
            });
    }

    // Handle order button clicks
    document.querySelectorAll('.order-btn').forEach(button => {
        button.addEventListener('click', () => {
            const itemName = button.getAttribute('data-item');
            const itemPrice = parseFloat(button.getAttribute('data-price'));

            // Check if the item is already in the order
            const existingItem = order.find(item => item.name === itemName);
            
            if (existingItem) {
                // Update the quantity if the item is already in the order
                existingItem.quantity++;
            } else {
                // Add new item to the order
                order.push({ name: itemName, price: itemPrice, quantity: 1 });
            }

            // Update the total price
            totalPrice += itemPrice;

            // Update the order summary on the page
            updateOrderSummary();
        });
    });

    // Handle the "Place Order" button click
    document.getElementById('place-order').addEventListener('click', () => {
        if (order.length === 0) {
            alert('Your order is empty!');
        } else {
            const firstName = document.getElementById('customer-first-name').value.trim();
            const lastName = document.getElementById('customer-last-name').value.trim();
            const phone = document.getElementById('customer-phone').value.trim();
            
            if (!firstName || !lastName || !phone) {
                alert('Please enter your first name, last name, and phone number!');
                return;
            }

            // Validate phone number format (10-15 digits)
            if (!/^[0-9]{10,15}$/.test(phone)) {
                alert('Please enter a valid phone number (10-15 digits only)!');
                return;
            }

            // Send order to server
            fetch('/order', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ 
                    items: order, 
                    total: totalPrice,
                    firstName: firstName,
                    lastName: lastName,
                    phone: phone
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Order placed successfully!');
                    // Clear the order after placing
                    order = [];
                    totalPrice = 0;
                    updateOrderSummary();
                    // Clear the form fields
                    document.getElementById('customer-first-name').value = '';
                    document.getElementById('customer-last-name').value = '';
                    document.getElementById('customer-phone').value = '';
                } else {
                    alert('Failed to place order.');
                }
            })
            .catch(() => {
                alert('Error placing order.');
            });
        }
    });

    // Handle the "View My Orders" button click
    const viewOrdersBtn = document.getElementById('view-orders-btn');
    if (viewOrdersBtn) {
        viewOrdersBtn.addEventListener('click', () => {
            const phone = document.getElementById('view-phone').value.trim();
            
            if (!phone) {
                alert('Please enter your phone number!');
                return;
            }

            // Validate phone number format
            if (!/^[0-9]{10,15}$/.test(phone)) {
                alert('Please enter a valid phone number (10-15 digits only)!');
                return;
            }

            // Fetch orders for this phone number
            fetch(`/api/my-orders/${phone}`)
                .then(response => response.json())
                .then(data => {
                    displayMyOrders(data);
                    localStorage.setItem('phoneNumber', phone);
                    startOrderTracking(phone);
                })
                .catch(error => {
                    console.error('Error fetching orders:', error);
                    alert('Error fetching orders. Please try again.');
                });
        });
    }
});
