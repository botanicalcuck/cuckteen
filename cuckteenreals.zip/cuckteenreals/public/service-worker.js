// public/service-worker.js
self.addEventListener('install', event => {
  console.log('Service worker installed');
});

self.addEventListener('activate', event => {
  console.log('Service worker activated');
});

self.addEventListener('message', event => {
  console.log('Service worker received message:', event);
  if (event.data.type === 'showNotification') {
    const { title, message, icon } = event.data;
    console.log('Service worker showing notification:', title, message, icon);
    self.registration.showNotification(title, {
      body: message,
      icon: icon
    });
  } else {
    console.log('Service worker received unknown message:', event.data);
  }
});
